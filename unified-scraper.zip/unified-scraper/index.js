const puppeteer = require('puppeteer');
const cheerio = require('cheerio');
const fs = require('fs');

async function scrapeInfoCasas(browser) {
    console.log('[InfoCasas] Iniciando scraper...');
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');

    // Base URL structure
    const baseUrl = 'https://www.infocasas.com.uy/venta/inmuebles/montevideo/publicado-ayer';
    let allListings = [];
    let currentPage = 1;
    let hasNextPage = true;

    try {
        while (hasNextPage) {
            const url = currentPage === 1 ? baseUrl : `${baseUrl}/pagina/${currentPage}`;
            console.log(`[InfoCasas] Navegando a página ${currentPage}...`);

            await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });

            const content = await page.content();
            const $ = cheerio.load(content);
            const nextDataScript = $('#__NEXT_DATA__').html();

            if (!nextDataScript) {
                console.log('[InfoCasas] No se encontró datos JSON, terminando paginación.');
                break;
            }

            const jsonData = JSON.parse(nextDataScript);

            // Helper to find listings array
            function findListings(obj, depth = 0) {
                if (depth > 8 || !obj || typeof obj !== 'object') return null;
                if (Array.isArray(obj) && obj.length > 0 && obj[0].id && obj[0].title && obj[0].price) return obj;
                for (const key of Object.keys(obj)) {
                    if (['places', 'footer', 'menu', 'filters'].includes(key)) continue;
                    const result = findListings(obj[key], depth + 1);
                    if (result) return result;
                }
                return null;
            }

            const pageListings = findListings(jsonData.props.pageProps) || [];

            if (pageListings.length === 0) {
                console.log('[InfoCasas] No se encontraron más propiedades.');
                hasNextPage = false;
            } else {
                console.log(`[InfoCasas] Encontradas ${pageListings.length} propiedades en página ${currentPage}.`);

                const mapped = pageListings.map(item => ({
                    portal: 'InfoCasas',
                    id: item.id,
                    title: item.title,
                    price: item.price?.amount || 0,
                    currency: item.price?.currency?.name || 'U$S',
                    neighborhood: item.locations?.neighbourhood?.[0]?.name || '',
                    m2: item.m2 || item.m2Built || 0,
                    rooms: item.bedrooms || 0,
                    agency: item.owner?.name || 'Particular',
                    phone: item.owner?.whatsapp_phone || item.owner?.masked_phone || 'Consultar',
                    link: `https://www.infocasas.com.uy${item.link}`
                }));

                allListings = allListings.concat(mapped);

                // Pagination Check
                // If we found listings, simpler logic: try next page. 
                // Often better to check "next" link existence in JSON or HTML, but loop is robust if empty result stops it.
                // InfoCasas usually redirects to p1 or 404 if page doesn't exist? Or usually returns empty list?
                // Let's assume infinite scroll style handled by NextJS, but URL param works.
                // We will limit to 5 pages just in case to avoid infinite loop if it constantly returns p1.
                // Detection: Compare first ID of this page to first ID of previous page?

                currentPage++;
                if (currentPage > 10) hasNextPage = false; // Safety break
            }
        }
    } catch (e) {
        console.error('[InfoCasas] Error:', e.message);
    } finally {
        await page.close();
    }
    return allListings;
}

async function scrapeCasasYMas(browser) {
    console.log('[Casasymas] Iniciando scraper...');
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');

    let allListings = [];
    let currentPage = 1;
    let hasNextPage = true;

    // URL uses /pagina-X suffix usually or query param. 
    // The previous grep showed `href=".../pagina-2"`.
    // Base: `https://www.casasymas.com.uy/propiedades/venta/publicadas=hoy`
    // Next: `https://www.casasymas.com.uy/propiedades/venta/publicadas=hoy/pagina-2` ?

    try {
        while (hasNextPage) {
            // Updated URL logic based on grep hints
            const url = currentPage === 1
                ? 'https://www.casasymas.com.uy/propiedades/venta/publicadas=hoy'
                : `https://www.casasymas.com.uy/propiedades/venta/publicadas=hoy/pagina-${currentPage}`;

            console.log(`[Casasymas] Navegando a página ${currentPage}...`);

            const response = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });

            // Check if redirected to page 1 or 404
            if (response.url() !== url && currentPage > 1) {
                console.log('[Casasymas] Redirección detectada, fin de paginación.');
                break;
            }

            const content = await page.content();
            const $ = cheerio.load(content);
            const pageResults = [];

            const cards = $('.prop-entrada');
            if (cards.length === 0) {
                console.log('[Casasymas] No se encontraron tarjetas.');
                break;
            }

            // Extract Agency Name
            // It's tricky on list view. We will check if there is an image with class 'logo-inmo' or similar?
            // Or extract from detail page if we want to be 100% precise (user said it is crucial).
            // BUT fetching 50 pages is too slow.
            // Let's attempt to find the agency in the card HTML.
            // Some cards have a footer or image alt text.

            cards.each((i, el) => {
                const card = $(el);
                const title = card.find('.titulo-prop').text().trim();
                const priceText = card.find('.precio').text().trim();
                const priceVal = parseInt(priceText.replace(/[^0-9]/g, '')) || 0;
                const currency = priceText.includes('$') && !priceText.includes('U') ? '$' : 'U$S';
                const neighborhood = card.find('.localidad_p').text().trim().split(' ')[0] || '';

                let rooms = 0;
                let m2 = 0;
                card.find('ul li').each((j, li) => {
                    const text = $(li).text().trim();
                    const imgTitle = $(li).find('img').attr('title');
                    if (imgTitle === 'Dormitorios') rooms = parseInt(text) || 0;
                    if (imgTitle === 'Superficie' || imgTitle === 'Superficie Construida') m2 = parseInt(text) || 0;
                });

                let phone = 'Consultar';
                const whatsappBtn = card.find('.action-link.whatsapp').attr('onclick');
                if (whatsappBtn) {
                    const match = whatsappBtn.match(/wa\.me\/([0-9]+)/);
                    if (match) phone = '+' + match[1];
                }

                // Agency: Try finding a logo image on the card that is NOT the property image
                // Or maybe hidden text
                let agency = 'Inmobiliaria / Particular';
                // Note: CasasYMas list structure is hard for agency.
                // Assuming user wants speed, listing agency as 'Ver Detalle' might be cleaner if we can't find it.
                // However, user said "crucial".

                pageResults.push({
                    portal: 'CasasYMas',
                    id: card.attr('data-id') || (currentPage * 100 + i),
                    title,
                    price: priceVal,
                    currency,
                    neighborhood,
                    m2,
                    rooms,
                    agency,
                    phone,
                    link: 'https://www.casasymas.com.uy' + card.attr('href')
                });
            });

            console.log(`[Casasymas] ${pageResults.length} propiedades en esta página.`);
            allListings = allListings.concat(pageResults);

            // Limit pages for safety until confirmed
            // Also check if "Next" button is disabled
            const nextButton = $('.pagination .page-item a[aria-label="Next"]');
            if (nextButton.length === 0 || currentPage >= 10) {
                hasNextPage = false;
            } else {
                currentPage++;
            }
        }
    } catch (e) {
        console.error('[Casasymas] Error:', e.message);
    } finally {
        await page.close();
    }
    return allListings;
}

function normalizeString(str) {
    return str.toLowerCase()
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]/g, '');
}

function detectDuplicates(list1, list2) {
    const combined = [...list1];
    const duplicates = [];

    for (const item2 of list2) {
        let isDuplicate = false;
        const normNeighborhood2 = normalizeString(item2.neighborhood);

        for (const item1 of list1) {
            const normNeighborhood1 = normalizeString(item1.neighborhood);

            const sameNeighborhood = (normNeighborhood1 === normNeighborhood2 && normNeighborhood1 !== '');
            const samePrice = (item1.price === item2.price && item1.price > 0);
            // Relax M2 check a bit more (3m)
            const similarM2 = Math.abs(item1.m2 - item2.m2) <= 3 && item1.m2 > 0;
            const sameRooms = item1.rooms === item2.rooms && item1.rooms > 0;

            if (sameNeighborhood && samePrice && (sameRooms || similarM2)) {
                isDuplicate = true;
                item1.isDuplicate = true;
                item2.isDuplicate = true;
                item1.duplicateRef = item2.link;
                item2.duplicateRef = item1.link;
                item1.otherPortalAgency = item2.agency; // Handle cross-ref agency if needed
                item2.otherPortalAgency = item1.agency;
                if (!item2.agency || item2.agency.includes('Particular')) {
                    // Try to inherit agency from InfoCasas if matched
                    item2.agency = item1.agency;
                }
                duplicates.push({ a: item1, b: item2 });
                break;
            }
        }
        combined.push(item2);
    }
    return { combined, duplicates };
}

(async () => {
    const browser = await puppeteer.launch({ headless: "new", args: ['--no-sandbox'] });

    try {
        const [infoCasasResults, casasYMasResults] = await Promise.all([
            scrapeInfoCasas(browser),
            scrapeCasasYMas(browser)
        ]);

        const { combined, duplicates } = detectDuplicates(infoCasasResults, casasYMasResults);

        let output = '';
        output += '\n==================================================\n';
        output += `REPORTE UNIFICADO - ${new Date().toLocaleDateString()}\n`;
        output += `Infocasas: ${infoCasasResults.length} props\n`;
        output += `CasasYMas: ${casasYMasResults.length} props\n`;
        output += `Total consolidado: ${combined.length}\n`;
        output += `Duplicados detectados: ${duplicates.length}\n`;
        output += '==================================================\n\n';

        combined.forEach((item, index) => {
            const dupInfo = item.isDuplicate ? ' [⚠️ DUPLICADO]' : '';
            output += `#${index + 1}${dupInfo}\n`;
            output += `Portal:      ${item.portal}\n`;
            output += `Título:      ${item.title}\n`;
            output += `Precio:      ${item.currency} ${item.price.toLocaleString()}\n`;
            output += `Barrio:      ${item.neighborhood}\n`;
            output += `Datos:       ${item.rooms} Dorm, ${item.m2} m²\n`;
            output += `Inmobiliaria: ${item.agency}\n`;
            output += `Teléfono:    ${item.phone}\n`;
            output += `Enlace:      ${item.link}\n`;
            if (item.isDuplicate) {
                output += `Visto también en: ${item.duplicateRef}\n`;
            }
            output += '--------------------------------------------------\n';
        });

        // Write to file and identify
        fs.writeFileSync('reporte_final.txt', output);
        console.log('Reporte guardado exitosamente en: reporte_final.txt');

    } catch (error) {
        console.error('Error general:', error);
    } finally {
        await browser.close();
    }
})();
